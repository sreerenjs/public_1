
package com.test;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.remote.DesiredCapabilities;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

/**
 * @author Sreerenj
 *
 */
public class TestCase {

		Homepage home= new Homepage();
                CommonUtility common =new CommonUtility();

	AppiumDriver<MobileElement> driver;
	String path;
	
	public void setup()
	{
		System.out.println("Session is creating");
		path = System.getProperty("user.dir");
		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setCapability("platformName", "Android");
		cap.setCapability("deviceName", "Samsung S9");
		cap.setCapability("app", path+"//app//ebay.apk");
		try {
			driver = new AndroidDriver<MobileElement>(new URL("http://0.0.0.0:4723/wd/hub"), cap);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		System.out.println("Session is created");
	}
	
	
	public static void main(String[] args) {

		
		setup();
		home.Login(driver,test,TestName, dataTab); 
                home.SearchProduct(driver,test,TestName, dataTab); 
		home.SearchProductContentVerify(driver,test,TestName, dataTab);  
		common.tearDown();

	}
}
