package com.utility;

import com.google.gson.Gson;
import com.relevantcodes.extentreports.ExtentTest;

public class ExtentReportsMerging {

	/**
	 * Function to clone the Extent test loggernew
	 * Through this deep cloning we get an identical copy of the cloned object
	 *  
	 * @param loggernew1	:	instance of the class Extent test to be cloned
	 * @return a clone of the loggernew1instance which is deep cloned
	 */
	public static ExtentTest cloneThroughJson(ExtentTest loggernew1) {
		// TODO Auto-generated method stub
		Gson gson = new Gson();
		String json = gson.toJson(loggernew1);
		return (ExtentTest) gson.fromJson(json, loggernew1.getClass());
	}

}
