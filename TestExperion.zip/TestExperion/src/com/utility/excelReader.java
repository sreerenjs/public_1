package com.utility;


import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import junit.framework.Assert;

public class excelReader{

	public static File dataSrc;
	
	public String toExecute;
	public static Sheet testdataSheet;
	public static CommonUtility commonUtility=new CommonUtility();
	public java.util.List<Object> GetDataRow(ExtentTest test, String testName,String SheetName) throws EncryptedDocumentException, InvalidFormatException, IOException{
		
		 		
	ReadPropertyFile conFile=new ReadPropertyFile();
	String RootPath = System.getProperty("user.dir");
	String dataPath=(RootPath+"/TestData/ExperionTestData.xlsx");
	
	DOMConfigurator.configure(RootPath +"/log4j.properties");
	
	try{
	//Load & Read data sheet
	dataSrc=new File(dataPath);
	FileInputStream fis=new FileInputStream(dataSrc); //load file
	wb=WorkbookFactory.create(fis);
	regionSheet = wb.getSheet("Region");
	
				//Get Last raw of data for transaction
					int lastRowofSheet=transactionDataSheet.getLastRowNum();
							for ( LR=1; LR<=lastRowofSheet;LR++){
						 String TestData = transactionDataSheet.getRow(LR).getCell(0).getStringCellValue().toString();
						if (TestData.equals("EndTest")){
							TransactionEndRow=(LR-1);
							test.log(LogStatus.INFO, "Test data available");
							break;
						    
						}
						else if(LR==lastRowofSheet){
							test.log(LogStatus.WARNING, " Please check the data, looks like no data in data sheet");
						}
								
					}
			
		}
		//Get he row for a specific test
		else {
			fromEmail=regionSheet.getRow(1).getCell(3).getStringCellValue();
			toEmail=regionSheet.getRow(1).getCell(4).getStringCellValue();
			transactionDataSheet=wb.getSheet(SheetName);
			int lastRowofSheet=transactionDataSheet.getLastRowNum();
						System.out.println("TransactionEndRow:"+ TransactionEndRow);
			for ( TDR=1; TDR<=lastRowofSheet;TDR++){
				 String TestData = transactionDataSheet.getRow(TDR).getCell(0).getStringCellValue().toString();
				 toExecute = transactionDataSheet.getRow(TDR).getCell(1).getStringCellValue().toString();
				 System.out.println("toExecute: " + toExecute);
				if (TestData.equals(testName)){
					testDataRow=(TDR);
					System.out.println("testDataRow:"+ testDataRow);
					 break;
				    
				}
				else if(TDR==lastRowofSheet){
				test.log(LogStatus.WARNING,"Test case in not available in test sheet tab Please check the test data.");
				}
			}
		}
			
}
catch(Exception execption){
	System.out.println("Exception : " +  execption + " Please check the path of test data");
	test.log(LogStatus.WARNING,execption + " Please check the test data, looks like there is issue with data sheet");
	
}

return Arrays.asList(wb,transactionDataSheet,dataSrc,TransactionPostURL,TransactionEndRow,testDataRow);
}
	
//-------------------------------------------------------------------------------------------------
	public String toExecute(Sheet dataSheet, int reqRow){
		
		  toExecute = dataSheet.getRow(reqRow).getCell(1).getStringCellValue().toString();
		  
		  return toExecute;
	}
		

//---------------------------------------------------------------------------------------------------------

public List<Object> getRowcound(String sheetName,ExtentTest test){
	
			int rowCount=0;
			String RootPath = System.getProperty("user.dir");
			String dataPath=(RootPath+"/TestData/VCAutomation_Data.xlsx");
			
			try{
			//Load & Read data sheet
				dataSrc=new File(dataPath);
				FileInputStream fis=new FileInputStream(dataSrc); //load file
				wb=WorkbookFactory.create(fis);
				testdataSheet = wb.getSheet(sheetName);
				int lastRowofSheet=testdataSheet.getLastRowNum();
				for ( LR=1; LR<=lastRowofSheet;LR++){
				String TestData = testdataSheet.getRow(LR).getCell(0).getStringCellValue().toString();
					if (TestData.equals("EndTest")){
						 rowCount = (LR-1);
					break;
					}
					else if(LR==0){
						test.log(LogStatus.WARNING, " Please check the data, looks like no data in data sheet");
					}
				}

			}
		
			catch(Exception execption){
				System.out.println("Exception : " +  execption + " Please check the path of test data");
				test.log(LogStatus.WARNING,execption + " Please check the test data, looks like there is issue with data sheet");
				
			}
		
			return Arrays.asList(wb,testdataSheet,dataSrc,TransactionPostURL,TransactionEndRow,rowCount);
			
		
		}
//-------------------------------------------------------------------------------------------------------------------------
public static int findColIndex(Sheet sheet, String cellContent, int occur) {

    int countOccur = 0;

      for (Row row : sheet) {

            for (Cell cell : row) {

            if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
            	String cellData=cell.getRichStringCellValue().getString().trim();
                if (cellData.equals(cellContent.trim())) {
                   //return row.getRowNum();
                  countOccur++;
                  if (countOccur==occur) {
                	  return cell.getColumnIndex();

                 }
               

                }

            }

        }

    }              


    return 0;

}

///_____________________________________________________________________________________________________________________
@SuppressWarnings("deprecation")
public static  String getCellData(WebDriver driver, ExtentTest test, Sheet sheet, Row dataRow, String colHeading) {

FormulaEvaluator evaluator = wb.getCreationHelper().createFormulaEvaluator();
String cellData=null;
int colIndex=findColIndex( sheet, colHeading, 1);
if (!(colIndex==0)){
	Cell cell = dataRow.getCell(colIndex);
	if (cell!=null){
			 if(cell.getCellType()==Cell.CELL_TYPE_BOOLEAN) {
				      	 cellData = String.valueOf(cell.getBooleanCellValue());
				      	 
			     } 
			 else if(cell.getCellType()==Cell.CELL_TYPE_NUMERIC){ 
				 //int data=(int) cell.getNumericCellValue();
				 if (cell.getNumericCellValue() % 1==0){
					 cellData= new BigDecimal(cell.getNumericCellValue()).toPlainString();
				 }
				 else{
				 BigDecimal Data= new BigDecimal(cell.getNumericCellValue());
				 BigDecimal RoundData=Data.setScale(2,BigDecimal.ROUND_HALF_UP);
				 cellData= RoundData.toPlainString();
				 }
			        	//cellData = String.valueOf(cell.getNumericCellValue());
			 }
			else if(cell.getCellType()==Cell.CELL_TYPE_STRING){ 
				
			        	 cellData = cell.getStringCellValue();
			       }
			else if(cell.getCellType()==Cell.CELL_TYPE_FORMULA){ 
				 cellData = cell.getStringCellValue();
			}
	}
	}
	else{
		cellData="No Header";
		test.log(LogStatus.WARNING,"Required colum header: "+colHeading+" is not available in data sheet, please update data sheet & resume execution");
		commonUtility.tearDown(driver);
	}
	
		 return cellData;

	
}
//---------------------------------------------------------------------------------------------------------------

public static void writeDataToDataSheet(String colHeading, String value) throws IOException{

	Row dataRow = transactionDataSheet.getRow(testDataRow);
	int colIndex=findColIndex( transactionDataSheet, colHeading, 1);
	
	 Cell cell = dataRow.getCell(colIndex);
	 cell.setCellValue("");
	cell.setCellValue(value);
	FileOutputStream fileOut = new FileOutputStream(dataSrc);
    wb.write(fileOut);
    fileOut.flush();
    fileOut.close();
}
 //----------------------------------------------------------------------------------------------------
   




}