package com.utility;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.xml.DOMConfigurator;
import org.apache.maven.shared.utils.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class ScreenPrint {
	SimpleDateFormat dateTimeFormat = new SimpleDateFormat("dd.MM.YYYY-HH.mm.ss");
	Date reportStamp = new Date();
	String reportTimeStamp = dateTimeFormat.format(reportStamp);
	Date currentDateTime = null;
	String dateTime = null;


    public String VCTakeScreenShot(WebDriver driver, String testName) throws Exception{
    	String RootPath = System.getProperty("user.dir");
	 	String dataPath=(RootPath+"/ScreenPrint");
	 	SimpleDateFormat dateFormat=new SimpleDateFormat("dd_MM_YYYY");
		SimpleDateFormat dateTimeFormat=new SimpleDateFormat("dd_MM_YYYY_HH_mm_ss");
		Date date=new Date();
		String strDate = dateFormat.format(date);
		String dirname=(RootPath + "/ScreenPrint/ScreenPrint_"+ strDate);
		File dir=new File(dirname);
		if(!dir.exists())dir.mkdirs();
		String imagestrDate = dateTimeFormat.format(date);
		String reportscreenshotpath = dirname + "//"+testName+"_"+imagestrDate  +".png";
    	
        //Call take screenshot function
        	//SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");  
        this.takeSnapShot(driver,reportscreenshotpath ) ; 
        return reportscreenshotpath;

    }


    public static void takeSnapShot(WebDriver webdriver,String fileWithPath) throws Exception{

        //Convert web driver object to TakeScreenshot
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");   
        TakesScreenshot scrShot =((TakesScreenshot)webdriver);

        //Call getScreenshotAs method to create image file

                File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);

            //Move image file to new destination

                File DestFile=new File(fileWithPath);

                //Copy file at destination

                FileUtils.copyFile(SrcFile, DestFile);

    }

}
