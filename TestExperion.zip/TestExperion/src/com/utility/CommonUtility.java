package com.utility;


import com.gemini.tests.CoreExecutor;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

//------------------------------------------------------------------------
public class CommonUtility {
	 

	public ExtentTest getTest(String PackageName, String className) {
		ExtentReports extentReport = coreexecutor.extentReport;

		test = extentReport.startTest(className, PackageName);
		return test;
	}

	// ------------------------------------------------------------------------
	// Close & Quit driver
	public void tearDown(WebDriver driver) {
		driver.close();
		driver.quit();
	}

	// ------------------------------------------------------------------------------
	// stop test & send email
	public void sendEmailStopTest(WebDriver driver, ExtentTest test, String message) {

		test.log(LogStatus.FAIL, message);

		this.tearDown(driver);
		// Sent email to recipients
		CoreExecutor CE = new CoreExecutor();
		String reportPath = CE.extentReportPath;
		ExtentReports extentReport = CE.extentReport;
		extentReport.flush();
		SendFileEmail email = new SendFileEmail();
		email.sentemail(reportPath);
		 

	}
	 // click object------------------------------------------------------------------------------------
	public void clickObj(WebDriver driver, ExtentTest test, By object) {
		// Set the timeout to something low
		// driver.manage().timeouts().implicitlyWait(1000,
		// TimeUnit.MILLISECONDS);
		try {
			driver.findElement(object).click();
			System.out.println("test");
			// driver.manage().timeouts().implicitlyWait(1000,
			// TimeUnit.MILLISECONDS);
		} catch (NoSuchElementException e) {
			// If element isn't found, set the timeout and return false
			driver.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);
			test.log(LogStatus.FAIL, e + "Required obj to click is not present in page");
		}
	}

	 
	// ----------------------------------------------------------------------------------------
	// select radioButton
	public void selectRadiobutton(WebDriver driver, ExtentTest test, By object) {
		// Set the timeout to something low
		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);
		try {
			driver.findElement(object).click();
			driver.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);
		} catch (NoSuchElementException e) {
			// If element isn't found, set the timeout and return false
			driver.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);
			test.log(LogStatus.FAIL, e + "Required Radio buttonis not present in page");
		}
	}

	// ----------------------------------------------------------------------------------------
	// select checkBox
	public void selectCheckbox(WebDriver driver, ExtentTest test, By object) {
		// Set the timeout to something low
		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);
		try {
			driver.findElement(object).click();
			// test.log(LogStatus.PASS,"Seleted the check box");
			driver.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);
		} catch (NoSuchElementException e) {
			// If element isn't found, set the timeout and return false
			driver.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);
			test.log(LogStatus.FAIL, e + "Required Check Box not present in page");
		}
	}

	// ----------------------------------------------------------------------------------------
	// select Value from Dropdown
	public void selectVlueFromDropdown(WebDriver driver, ExtentTest test, By object, String value) {
		// Set the timeout to something low
		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);
		try {
			Select dropDoenObj = new Select(driver.findElement(object));
			dropDoenObj.selectByVisibleText(value);
			driver.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);
		} catch (NoSuchElementException e) {
			// If element isn't found, set the timeout and return false
			driver.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);
			test.log(LogStatus.FAIL, e + "Required Dropdown field not present in page");
		}
	}

	// ----------------------------------------------------------------------------------------
	// javascript click
	public void javascriptClick(WebDriver driver, ExtentTest test, By object) {
		// Set the timeout to something low
		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);
		try {
			WebElement element = driver.findElement(object);
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", element);

			driver.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);
		} catch (NoSuchElementException e) {
			// If element isn't found, set the timeout and return false
			driver.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);
			test.log(LogStatus.FAIL, e + "Required obj to click is not present in page");
		}
	}

	
	// --------------------------------------------------------------------------------------------------------
	//Alert popup
public boolean isAlertPresent(WebDriver driver) {
		try {

			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException exception) {
			return false;
		}

	}
	

}
