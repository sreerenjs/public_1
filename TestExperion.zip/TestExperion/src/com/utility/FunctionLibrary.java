package com.utility;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



public class FunctionLibrary {
	private static WebDriver driver;
	public static String te = "wq";
	private final Logger logger = Log.getInstance(Thread.currentThread().getStackTrace()[1].getClassName());


	/**
	 * This function is to switch the driver from Current Window to newly opened
	 * Window
	 * 
	 * @param driver
	 */
	public static void switchToWindow() {
		try {
			for (String windowHandle : driver.getWindowHandles()) {
				driver.switchTo().window(windowHandle);
			}

		} catch (NoSuchWindowException e) {

		}
	}
	
	public static void switchToWindowTitle(WebDriver driver,String str) 

    {

		String currentWindow = driver.getWindowHandle();  //will keep current window to switch back
		for(String winHandle : driver.getWindowHandles()){
		   if (driver.switchTo().window(winHandle).getTitle().equals(str)) {
		     //This is the one you're looking for
		     break;
		   } 
		   else {
		      driver.switchTo().window(currentWindow);
		   } 
		}

           

    }

	public static void pressEnter(WebDriver driver)
	{
		Actions act=new Actions(driver);
		act.sendKeys(Keys.ENTER).build().perform();
	}
	public static void switchToFrame(WebDriver driver,WebElement element)
	{
		driver.switchTo().frame(element);
	}

	public static void defaultContent(WebDriver driver)
	{
		driver.switchTo().defaultContent();
	}
	public static void senKeys(WebDriver driver,WebElement element,String txt)
	{
		try {

			//AppSyncHandler.syncTill(driver, "visibilityOfElement", element,  0, 1, "NA");
			element.sendKeys(txt);

		} catch (Throwable e) 
		{

			System.out.println();
		}
	}

	public static void clickElement(WebDriver driver,WebElement element)
	{
			//AppSyncHandler.syncTill(driver, "elementToBeClickable", element,  0, 1, "NA");
			element.click();

	}
	
	public static void sendElementThenPressEnter(WebDriver driver,WebElement element,String txt)
	{
			//AppSyncHandler.syncTill(driver, "elementToBeClickable", element,  0, 10, "NA");	
			element.clear();
			
			AppSyncHandler.syncTill(driver, " ", null,  0, 3, "NA");
			element.sendKeys(txt);
			AppSyncHandler.syncTill(driver, "", null, 0, 3, "NA");
			pressEnter(driver);
	}

	public static void clickElementUsingJavaScript(WebDriver driver,WebElement element)
	{
		
		//AppSyncHandler.syncTill(driver, "elementToBeClickable", element,  0, 2, "NA");
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", element);

	}
	public static void assertTruePopupValidation(WebElement ele) {

		try {

			Assert.assertTrue(ele.isDisplayed());

		}

		catch (Exception e) {

			System.out.println(e.getStackTrace());

		}

	}

	public static String getTextByValueAttribute(WebElement ele) {
		String text = null;
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		try {
			text = ele.getAttribute("value");
		} catch (NullPointerException ex) {

			text = (String) jse.executeScript("return arguments[0].text", ele);
		}
		return text;

	}

	public static boolean isASubString(String statement, String substringstr) {
		if (statement.contains(substringstr) && (statement.contains("not"))) {
			System.out.println("yes");
			return false;
		} else if ((statement.contains("not"))) {
			return false;
		} else
			return true;

	}

	public static void assertStringEquals(String expected_text, String actual_text) {

		try {

			Assert.assertEquals(expected_text, actual_text);
			System.out.println("Expected text " + expected_text + " and Actual text " + actual_text + " are same.");
		} catch (Exception e) {
			System.out.println("Expected [ " + expected_text + " ] but found [ " + actual_text + " ]");
			System.out.println(e.getStackTrace());
		}

	}


	/**
	 * This function is to switch into a frame; frame is located as a webelemet
	 * 
	 * @param locator - By object of the webelemet using which frame can be located
	 * @param driver
	 */
	public static void switchToFrameByWebElement(WebElement el) {
		try {
			driver.switchTo().frame(el);

		} catch (NoSuchFrameException e) {

		}
	}

	public static void assertStringEmpty(String condition) {

		try {
			Assert.assertTrue(condition != null, " Field not get populated.");
			System.out.println(" Field get Populated");
		} catch (Exception e) {
			// System.out.println(condition+" field not populated.");
			System.out.println(e.getStackTrace());
		}
	}

	public static void checkedByValue(WebElement showPlan)

	{
		try {
			String checked_value = showPlan.getAttribute("checked");

			System.out.println("checked" + checked_value);

			if (checked_value.equalsIgnoreCase("true"))

			{

				System.out.println("Option is Checked");

			}

			else

				System.out.println("Option not checked");

		} catch (Exception e) {

		}
	}


	/**
	 * This function is to click on an element by moving the mouse pointer to the
	 * specified location or to read the tip of a mouse
	 * 
	 * @param locator - By object to locate the element to which mouse pointer has
	 *                to be moved
	 * @param driver
	 */
	public static void moveMouseTipAndClick(WebElement webele,WebDriver driver) {
		try {
			//WebElement element = driver.findElement(locator);
			WebElement element =webele;
			Locatable hoverItem = (Locatable) element;
			Mouse mouse = ((HasInputDevices) driver).getMouse();
			mouse.mouseMove(hoverItem.getCoordinates());
			mouse.click(hoverItem.getCoordinates());
		} catch (NoSuchElementException e) {

		}
	}


	public static void checked(WebElement element)

	{

		String checked = element.getAttribute("ev");

		System.out.println("checked" + checked);

		if (checked.equalsIgnoreCase("true"))

		{

			System.out.println("Option is Checked");

		}

		else

			System.out.println("Option not checked");

	}


	/**
	 * This function is to switch the driver from Current Window to newly opened
	 * Window
	 * 
	 * @param driver
	 */
	public static void switchToWindow(WebDriver driver) {
		try {
			for (String windowHandle : driver.getWindowHandles()) {
				driver.switchTo().window(windowHandle);
			}

		} catch (NoSuchWindowException e) {

		}
	}


	public static void assertTruePopupValidation(WebElement ele, WebDriver driver) {

		try {

			Assert.assertTrue(ele.isDisplayed());

			System.out.println("pop up displayed.");

		}

		catch (Exception e) {

			System.out.println("pop up not displayed");

			System.out.println(e.getStackTrace());

		}

	}

	public static String getTextByValueAttribute(WebElement ele, WebDriver driver) {
		String text = null;
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		try {
			text = ele.getAttribute("value");
		} catch (NullPointerException ex) {

			text = (String) jse.executeScript("return arguments[0].text", ele);
		}
		return text;

	}


	/**	This function is to compare dates

	 */

	public static boolean compareDates(String appDate) throws ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat("M/dd/yy");
		Date date = new Date();
		Date sysdate = formatter.parse(formatter.format(date));
		Date date1 = formatter.parse(appDate);
		try {
			if (sysdate.equals(date1)) {			
				////test.log(LogStatus.PASS, "Date matches with system date");
				return true;
			}


		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
			////test.log(LogStatus.FAIL, "Date Not matches with system date");
		}
		return false;
	}

	/**
	 * This function is to switch into a frame; frame is located as a webelemet
	 * 
	 * @param locator - By object of the webelemet using which frame can be located
	 * @param driver
	 */
	public static void switchToFrameByWebElement(WebElement el, WebDriver driver) {
		try {
			driver.switchTo().frame(el);

		} catch (NoSuchFrameException e) {

		}
	}



	public static void checkedByValue(WebElement showPlan, WebDriver driver) 

	{
		try {
			String checked_value = showPlan.getAttribute("checked");

			System.out.println("checked" + checked_value);

			if (checked_value.equalsIgnoreCase("true"))

			{

				System.out.println("Option is Checked");

			}

			else

				System.out.println("Option not checked");

		}catch(Exception e) {

		}
	}

	public boolean isDisplayed(By locator, String attribute,WebDriver driver ) {
		boolean text = true;
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		try {
			text = driver.findElement(locator).isDisplayed();
		} catch (NullPointerException ex) {
			WebElement element = driver.findElement(locator);
			text = (Boolean) jse.executeScript("return arguments[0].text", element);
		}
		return true;
	}

	/** To validate date
	 * @param actual_Date
	 * @param logger
	 * @return
	 */
	public static boolean validateDate(String actual_Date) {
		boolean valid = false;
		try {			
			valid = compareDates(actual_Date);

		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return valid;
	}

	public static int extractInt(String str) {
		Matcher matcher = Pattern.compile("\\d+").matcher(str);

		if (!matcher.find())
			throw new NumberFormatException("For input string [" + str + "]");

		return Integer.parseInt(matcher.group());
	}
	public static String removeWhiteSpace(String temp)

    {

            return temp.replaceAll("\\s","").trim();

    }
	 

}
