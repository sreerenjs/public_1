package com.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.zeroturnaround.zip.ZipUtil;

public class ReadPropertyFile {
public  String AppuserID;
public  String Apppassword;


	public ReadPropertyFile(){ 
		// TODO Auto-generated method stub
			Properties prop=new Properties();
			FileInputStream ip = null;
			String RootPath = System.getProperty("user.dir");
			try {
				ip = new FileInputStream(RootPath +"/config/config.properties");
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				
			}
			try {
				prop.load(ip);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}
			ExperionuserID=prop.getProperty("AppuserID");
			Experionpassword =prop.getProperty("appPassword");
			 
	}
	

		
		

			
		
	}

	
	
