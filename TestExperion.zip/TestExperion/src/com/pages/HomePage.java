package com.pages;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;




public class HomePage   {
	CoreExecutor coreexecutor=new CoreExecutor();
	CommonUtility commonUtility=new CommonUtility();
	ExtentTest test;
	public static Sheet dataSheet;



	private static WebDriver driver;
	public static final String flag = "NA";
	By login=By.xpath("//a[@id='login_link']");
	By username=By.xpath("//a[@id='user_name']");
        By password=By.xpath("//a[@id='pass_wrd']");
        By loginBtn=By.xpath("//a[@id='login1']");
	By HomePageTitleValidate=By.xpath("//a[@id='HomeTitle']");
        By search=By.xpath("//a[@id='searchArea']");
        By searchBtn=By.xpath("//a[@id='searchBtn']");
 	By searchResult=By.xpath("//a[@id='searchResultPage']");

        By verfyName=By.xpath("//a[@id='verfyName']");
  	By verfyPrice=By.xpath("//a[@id='verfyPrice']");
	By verfyDesc=By.xpath("//a[@id='verfyDesc']");
	
 

	public void  Login(WebDriver driver, ExtentTest test) throws EncryptedDocumentException, InvalidFormatException, IOException {
			excelReader getRow = new excelReader();
			String testName = TestName;
			List<Object> excelObj = getRow.GetDataRow(test, testName, dataTab);
			int testDataRow = 0;
			int lastColumn = 0;
			dataSheet = (Sheet) excelObj.get(1);
			testDataRow = (Integer) excelObj.get(5);

			// Test starts

			Row dataRow = dataSheet.getRow(testDataRow);

			String UserKey = excelReader.getCellData(driver,test,dataSheet, dataRow, "UserKey");
			String passKey = excelReader.getCellData(driver,test,dataSheet, dataRow, "passKey");

		try {


			delay.tillElementPresent(driver, "login",5);
			commonUtility.clickObj(driver, test,login);

			delay.tillElementPresent(driver, "username",5);
			commonUtility.clickObj(driver, test,username,UserKey);
 
                   	delay.tillElementPresent(driver, "password",5);
			commonUtility.sendKeys(driver, test,password,passKey);

  			delay.tillElementPresent(driver, "loginBtn",5);
			commonUtility.clickObj(driver, test,loginBtn);

			assertTrue(driver.findElement(HomePageTitleValidate).isDisplayed());
			test.log(LogStatus.PASS, "Login successfully" +UserKey);


		} catch (Exception e) {
			test.log(LogStatus.FAIL, "Failed to login the account");

		}

	}

	public void SearchProduct(WebDriver driver, ExtentTest test, String TestName, String dataTab)
			throws EncryptedDocumentException, InvalidFormatException, IOException {
		try {
			excelReader getRow = new excelReader();
			String testName = TestName;
			List<Object> excelObj = getRow.GetDataRow(test, testName, dataTab);
			int testDataRow = 0;
			int lastColumn = 0;
			dataSheet = (Sheet) excelObj.get(1);
			testDataRow = (Integer) excelObj.get(5);

			// Test starts

			Row dataRow = dataSheet.getRow(testDataRow);
			String SearchProduct = excelReader.getCellData(driver,test,dataSheet, dataRow, "SearchProduct");



			delay.tillElementPresent(driver, "username",5);
			commonUtility.clickObj(driver, test,search,SearchProduct);

			delay.tillElementPresent(driver, "login",5);
			commonUtility.clickObj(driver, test,searchBtn);


			assertTrue(driver.findElement(searchResult).isDisplayed());


			test.log(LogStatus.PASS, "Search result displayed  successfully");


		} catch (Exception e) {
			test.log(LogStatus.FAIL, "Search result failed to display");

		}

	}
	

	public void SearchProductContentVerify(WebDriver driver, ExtentTest test, String TestName, String dataTab)
		
	throws EncryptedDocumentException, InvalidFormatException, IOException {

//--------Product name validation-----------------------------
		try {
			 
  
  	 
			assertTrue(driver.findElement(verfyName).isDisplayed());


			test.log(LogStatus.PASS, "Product name verfied successfully");


		} catch (Exception e) {
			test.log(LogStatus.FAIL, "Product name verification failed ");

		}

//--------Product price validation-----------------------------
try {
			 
			assertTrue(driver.findElement(verfyPrice).isDisplayed());
			test.log(LogStatus.PASS, "Product price verfied successfully");


		} catch (Exception e) {
			test.log(LogStatus.FAIL, "Product price verification failed ");

		}
//--------Product description validation-----------------------------
try {

			assertTrue(driver.findElement(verfyDesc).isDisplayed());
			test.log(LogStatus.PASS, "Product description verfied successfully");


		} catch (Exception e) {
			test.log(LogStatus.FAIL, "Product description verification failed ");

		}

	}


}

